import {createContext} from 'react'

export const ReducerContext = createContext(null);